
int randomWithLimits(int øvregrense, int nedregrense);
