
#ifndef dynamiskMinneha_ndtering_hpp
#define dynamiskMinneha_ndtering_hpp

#include <stdio.h>
#include <iostream>
using namespace std;


void fillInFibonacciNumbers(int result[], int length);
void printArray(int arr[], int length);
void createFibonacci();

#endif /* dynamiskMinneha_ndtering_hpp */
